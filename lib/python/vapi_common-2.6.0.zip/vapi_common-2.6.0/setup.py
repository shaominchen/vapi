"""
Setup file for vAPI Common package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

from setuptools import setup, find_packages

setup(
    name='vapi_common',
    version='2.6.0',
    namespace_packages=['com'],
    packages=find_packages(),
    description='vAPI Common Services',
    install_requires=['vapi-runtime==2.6.0'],
    author='VMware',
)
