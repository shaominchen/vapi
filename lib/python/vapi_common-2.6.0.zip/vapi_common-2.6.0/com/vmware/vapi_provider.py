# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2016 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI skeleton file for package com.vmware.vapi.
#---------------------------------------------------------------------------

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.skeleton import VapiInterface, ApiInterfaceSkeleton
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.data.validator import UnionValidator, HasFieldsOfValidator




