"""
CLI metadata namespace service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'
__docformat__ = 'epytext en'

import logging
import six

from com.vmware.vapi.metadata.cli_provider import Namespace
from com.vmware.vapi.metadata.util.maps import get_cli_maps
from vmware.vapi.stdlib.provider.factories import MessageFactory, ErrorFactory
from vmware.vapi.bindings.skeleton import VapiFilter

messages = {
    'metadata.cli.not_found':
        'No metadata available for operation %s',
}
message_factory = MessageFactory(messages)
logger = logging.getLogger(__name__)
logger.addFilter(VapiFilter())


class NamespaceImpl(Namespace):
    """
    Operations to get details of CLI namespace nodes
    """
    def __init__(self, maps):
        Namespace.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get all the namespace nodes

        :rtype: :class:`list` of :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Identity`
        :return: List of Namespace nodes
        """

        ids = [value[1].identity
               for key, values in six.iteritems(self._maps.namespace_info)
               if key.rsplit('#')[-1] == 'namespace'
               for value in values]
        return list(set(ids))

    def get(self, **kwargs):
        """
        Get the details of a given namespace including details of child of
        that namespace in the CLI node tree

        :type  identity: :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Identity`
        :kwarg identity: Path and name of the namespace node

        :rtype: :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Info`
        :return: Namespace node details
        """

        identity = kwargs.get('identity')

        key = '%s#%s#%s' % (identity.path, identity.name, 'namespace')
        if key in self._maps.namespace_info:
            values = [val for _, val in self._maps.namespace_info[key]]
            ns_info = Namespace.Info(identity=values[0].identity,
                                     description=values[0].description,
                                     children=values[0].children)

            if len(values) > 1:
                children = []
                for ns in values:
                    children += ns.children
                ns_info.children = list(set(children))

            return ns_info
        else:
            msg = message_factory.get_message('metadata.cli.not_found', key)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])

    def fingerprint(self):
        """
        Fingerprint of all metadata on the server

        :rtype: :class:`str`
        :return: Fingerprint of metadata present on the server
        """
        return self._maps.namespace_fingerprint


def register_instance():
    """
    Specify the instances that should be
    registered with the api provider
    """
    return [NamespaceImpl(get_cli_maps())]
