"""
REST Rule generator
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2016 VMware, Inc.  All rights reserved.' + \
                '-- VMware Confidential'

import logging
import six

from werkzeug.routing import Rule

from com.vmware.vapi.metadata.metamodel_client import Type
from vmware.vapi.lib.constants import RestAnnotations
from vmware.vapi.settings import config


logger = logging.getLogger(__name__)


class MappingRule(object):
    """
    Base class for all the mapping rules. This will contain
    the common helper functions for all the rules.
    """
    def __init__(self):
        """
        Initialize MappingRule
        """
        self._rest_prefix = config.cfg.get('rest', 'prefix')
        if not self._rest_prefix.endswith('/'):
            self._rest_prefix = '%s/' % self._rest_prefix

    def _generate_service_base_url(self, service_id):
        """
        Generate base url for a particular service

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :rtype: :class:`str`
        :return: base url for all the HTTP REST URLs for a given service.
        """
        suffix = service_id.replace('_', '-').replace('.', '/').lower()
        return '%s%s' % (self._rest_prefix, suffix)

    @staticmethod
    def _get_id_suffix(param_info_map):
        """
        Generate suffix using the ID parameters

        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`str` or `None`
        :return: string that can be used in the URL to represent an identifier,
            if there is no identifier, None is returned
        """
        for param_name, param_info in six.iteritems(param_info_map):
            if param_info.type.category == Type.Category.BUILTIN:
                if param_info.type.builtin_type == Type.BuiltinType.ID:
                    # TODO: Handle composite identifiers
                    return '/<string:%s>' % param_name
        # No ID parameter
        return ''


class ListMappingRule(MappingRule):
    """
    Mapping rule that handles 'list' operations in the API
    and generates HTTP GET.

    Operations matched:
    list() -> GET /svc
    """
    def __init__(self):
        """
        Initialize ListMappingRule
        """
        MappingRule.__init__(self)

    # TODO: All the match methods for default mapping rules need to check if
    # there is a RequestMapping annotation and return False if present
    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'list' else False)

    def url(self, service_id, param_info_map):  # pylint: disable=W0613
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Metamodel metadata paramters for the operation
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        return (service_url, 'GET')


class PostMappingRule(MappingRule):
    """
    Mapping rule that handles 'create' operations in the API
    and generates HTTP POST.

    Operations matched:
    create() -> POST /svc
    create(...) -> POST /svc + body
    """
    def __init__(self):
        """
        Initialize PostMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'create' else False)

    def url(self, service_id, param_info_map):  # pylint: disable=W0613
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        return (service_url, 'POST')


class DeleteMappingRule(MappingRule):
    """
    Mapping rule that handles 'delete' operations in the API
    and generates HTTP DELETE.

    Operations matched:
    delete(ID id) -> DELETE /svc/<id>
    """
    def __init__(self):
        """
        Initialize DeleteMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'delete' else False)

    def url(self, service_id, param_info_map):
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        id_suffix = self._get_id_suffix(param_info_map)
        if id_suffix:
            return (service_url + id_suffix, 'DELETE')
        else:
            return (service_url, 'POST')


class GetMappingRule(MappingRule):
    """
    Mapping rule that handles 'get' operations in the API
    and generates HTTP GET.

    Operations matched:
    get(ID id) -> GET /svc/<id>
    """
    def __init__(self):
        """
        Initialize GetMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'get' else False)

    def url(self, service_id, param_info_map):
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        id_suffix = self._get_id_suffix(param_info_map)
        if id_suffix:
            return (service_url + id_suffix, 'GET')
        else:
            return (service_url, 'POST')


class PatchMappingRule(MappingRule):
    """
    Mapping rule that handles 'update' operations in the API
    and generates HTTP PATCH.

    Operations matched:
    update(ID id) -> PATCH /svc/<id>
    """
    def __init__(self):
        """
        Initialize PatchMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'update' else False)

    def url(self, service_id, param_info_map):
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        id_suffix = self._get_id_suffix(param_info_map)
        if id_suffix:
            return (service_url + id_suffix, 'PATCH')
        else:
            return (service_url, 'POST')


class PutMappingRule(MappingRule):
    """
    Mapping rule that handles 'set' operations in the API
    and generates HTTP PUT.

    Operations matched:
    set(ID id) -> PUT /svc/<id>
    """
    def __init__(self):
        """
        Initialize PutMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id == 'set' else False)

    def url(self, service_id, param_info_map):
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        id_suffix = self._get_id_suffix(param_info_map)
        if id_suffix:
            return (service_url + id_suffix, 'PUT')
        else:
            return (service_url, 'POST')


class PostActionMappingRule(MappingRule):
    """
    Mapping rule that handles non-crud operations in the API
    and generates HTTP POST.

    Operations matched:
    custom() -> POST /svc?~action=custom
    custom(ID id) -> POST /svc/<id>?~action=custom
    custom(...) -> POST /svc?~action=custom + body
    custom(ID id, ...) -> POST /svc/<id>?~action=custom + body
    """
    _crud_ops = ['create', 'get', 'list', 'update', 'set', 'delete']

    def __init__(self):
        """
        Initialize PostActionMappingRule
        """
        MappingRule.__init__(self)

    @staticmethod
    def match(operation_id):
        """
        Check if the given operation matches the criteria for this
        mapping rule.

        :type  operation_id: :class:`str`
        :param operation_id: Operation identifier
        :rtype: :class:`bool`
        :return: True, if the given operation matches the criteria
            for this mapping rule, False, otherwise.
        """
        return (True if operation_id not in PostActionMappingRule._crud_ops
                else False)

    def url(self, service_id, param_info_map):
        """
        Generate the URL for the given operation

        :type  service_id: :class:`str`
        :param service_id: Service identifier
        :type  param_info_map: :class:`collections.OrderedDict` of :class:`str`
               and :class:`com.vmware.vapi.metadata.metamodel_client.FieldInfo`
        :param param_info_map: Map of parameter name to its metamodel metadata
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """
        service_url = self._generate_service_base_url(service_id)
        id_suffix = self._get_id_suffix(param_info_map)
        return (service_url + id_suffix, 'POST')


class RoutingRuleGenerator(object):
    """
    Generate the routing rules based on vAPI metamodel metadata.
    """
    def __init__(self, metadata):
        """
        Initialize RoutingRuleGenerator

        :type  metadata: :class:`vmware.vapi.server.rest_handler.MetadataStore`
        :param metadata: Object that contains the relevant metamodel metadata of
            all the services.
        """
        self._metadata = metadata
        self._mapping_rules = [
            ListMappingRule(),
            PostMappingRule(),
            DeleteMappingRule(),
            GetMappingRule(),
            PatchMappingRule(),
            PutMappingRule(),
            PostActionMappingRule(),
        ]

    # TODO: Define a class CustomMappingRule and follow the same pattern as
    # other mapping rules
    @staticmethod
    def _get_custom_mapping_rule(request_mapping_element_map):
        """
        Generate the mapping rule for an operation that has RequestMapping
        in the VMODL2 service definition.
        Processing only "value" and "method" elements from the RequestMapping
        annotation

        Operation definition:
        @RequestMapping(value="/svc/{id}",
                        method=RequestMethod.POST,
                        contentType="...",
                        accept="...")
        @ResponseStatus(204)
        void custom(@PathVariable("user_id") ID id, ...)

        Generated mapping: POST /svc/{id} [+ body]

        :type  request_mapping_element_map:
            :class:`com.vmware.vapi.metadata.metamodel_client.ElementMap`
        :param request_mapping_element_map:
            Metamodel for the RequestMapping annotation on an operation
        :rtype: :class:`tuple` of :class:`str` and :class:`str`
        :return: Tuple that has URL and the HTTP method for the
            given operation.
        """

        custom_url = request_mapping_element_map.elements[
                        RestAnnotations.VALUE_PARAM].string_value
        custom_url = custom_url.replace('{', '<')
        custom_url = custom_url.replace('}', '>')

        http_method = request_mapping_element_map.elements[
                        RestAnnotations.METHOD_PARAM].string_value

        return (custom_url, http_method)

    def generate_mapping_rule(self, service_id, operation_id, operation_summary):
        """
        Generate HTTP REST rule from operation summary

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service
        :type  operation_id: :class:`str`
        :param operation_id: Identifier of the operation
        :type  operation_summary:
        :class:`vmware.vapi.server.rest_handler.MetadataStore.OperationSummary`
        :param operation_summary: Details of the operation
        :rtype: :class:`werkzeug.routing.Rule`
        :return: Class representing a mapping rule
        """
        # Generate custom mapping if there is an annotation on the method
        if operation_summary.has_request_mapping_metadata():
            service_url, http_method = self._get_custom_mapping_rule(
                operation_summary.request_mapping_metadata)
            endpoint = (service_id, operation_id)
        else:
            for mapping_rule in self._mapping_rules:
                if mapping_rule.match(operation_id):
                    service_url, http_method = \
                        mapping_rule.url(service_id,
                                         operation_summary.param_info_map)
                    # For default mappings, operation name comes as a query
                    # parameter. Werkzueg does not consider query parameter for
                    # rule matching. So, multiple operations could have the same
                    # URL mapping. This is why, OperationId is left blank here.
                    # When a request comes, the URL, method name and query
                    # parameters will be usd to determine the operation ID
                    endpoint = (service_id, None)
        return Rule(service_url, endpoint=endpoint, methods=[http_method])

    @property
    def rest_rules(self):
        """
        HTTP REST rules

        :rtype: :class:`werkzeug.routing.Map`
        :return: Map instance that has all the available HTTP REST rules
        """

        rules = [self.generate_mapping_rule(service_id,
                                            operation_id,
                                            operation_summary)
                 for service_id, service_info in six.iteritems(
                                                 self._metadata.service_map)
                 for operation_id, operation_summary in six.iteritems(
                                                        service_info)]

        return rules
