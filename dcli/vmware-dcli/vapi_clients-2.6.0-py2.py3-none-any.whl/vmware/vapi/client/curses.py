#!/usr/bin/env python

"""
Module for providing a curses UI backed by the API and CLI metadata.
"""

from __future__ import absolute_import

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015-2017 VMware, Inc.  All rights reserved.'

import logging
from pipes import quote
from optparse import OptionParser
import StringIO
import sys
import urwid

from vmware.vapi.data.definition import (
    OptionalDefinition, SecretDefinition, StructDefinition)
from vmware.vapi.data.serializers.introspection import convert_data_value_to_data_def
from vmware.vapi.lib.connect import get_connector
from vmware.vapi.client.parser import string_value_to_data_value
from vmware.vapi.client.lib.formatter import TableVisitor
from vmware.vapi.stdlib.client.factories import StubConfigurationFactory

from com.vmware.vapi.std.errors_client import NotFound
from com.vmware.vapi.metadata.cli_client import Namespace, Command
from com.vmware.vapi.std.introspection_client import Operation

urwid.Button.button_left = urwid.Text('')
urwid.Button.button_right = urwid.Text('')
logger = logging.getLogger(__name__)


class ParamEdit(urwid.Edit):
    """
    Class that wraps the urwid Edit widget for handling command parameters,
    managing parameter metadata and providing special-case handling for
    optional parameters.
    """
    _optional_hint = '<optional>'

    def __init__(self, defn, param, field=None):
        """
        Initializes the widget.

        :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
        :param defn: API parameter definition
        :type  param: :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
        :param param: CLI parameter definition
        :type  field: :class:`str` or ``None``
        :param field: Field name, if the widget represents a field of a structure
            (defn is a :class:`vmware.vapi.data.definition.StructDefinition`),
            otherwise None.
        """
        if field is None:
            caption = '%s: ' % param.name
        else:
            caption = '%s: ' % field.replace('_', '-')
            defn = defn.get_field(field)
        urwid.Edit.__init__(self, caption, edit_pos=0)
        if isinstance(defn, OptionalDefinition):
            self.edit_text = self._optional_hint
            defn = defn.element_type
        if isinstance(defn, SecretDefinition):
            self.set_mask('*')
            self.edit_text = ''
        self.param = param
        self.field = field

    def insert_text(self, text):
        """
        Inserts text into the widget.  If the widget currently contains
        the optional hint, the hint text is removed first.

        :type  text: :class:`str`
        :param text: New widget text.
        """
        if self.edit_text == self._optional_hint:
            self.edit_text = ''
        urwid.Edit.insert_text(self, text)

    def get_value(self):
        """
        Returns the contents of the widget, or None if the widget
        currently contains the optional hint.

        :rtype:  :class:`str` or ``None``
        :return: Widget contents, or None if the widget currently
            contains the optional hint.
        """
        if self.edit_text == self._optional_hint:
            return None
        else:
            return self.edit_text

    def get_param(self):
        """
        Returns the parameter associated with the widget.

        :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
        :return: CLI parameter definition associated with the widget
        """
        return self.param

    def get_field(self):
        """
        Returns the field of the parameter associated with the widget.

        :rtype:  :class:`str` or ``None``
        :return: CLI field name associated with the widget if the widget
            represents a field of a structure parameter, or None if the
            widget represents a primitive parameter.
        """
        return self.field


class CursesUI(object):
    """
    Class that implements a Curses UI backed by the API and CLI metadata.
    """
    def __init__(self, connector):
        """
        Initializes and renders the Curses UI.

        :type  connector: :class:`vmware.vapi.protocol.client.connector.Connector`
        :param connector: Connector to the API/CLI server
        """
        self._connector = connector
        self._api_provider = connector.get_api_provider()
        stub_config = StubConfigurationFactory.new_std_configuration(connector)
        self._namespace = Namespace(stub_config)
        self._command = Command(stub_config)
        self._operation = Operation(stub_config)
        self._cmd_path = []
        self._cmd_name = ''
        self._edit_list = []

        # Initialize palette

        blue = ('light blue', '#37c')
        white = ('white', '#fff')
        black = ('black', '#000')
        lgray = ('light gray', 'g#cc')
        dgray = ('dark gray', 'g#33')

        self._palette = [self._palette_entry('header', white, dgray, 'bold'),
                         self._palette_entry('footer', lgray, dgray),
                         self._palette_entry('subtitle', black, blue, 'bold'),
                         self._palette_entry('deselect', black, blue),
                         self._palette_entry('select', white, black),
                         self._palette_entry('listbox', black, blue)]

        # Initialize widgets

        self._title = urwid.Text('', wrap='clip', align='center')
        self._status = urwid.Text('', wrap='clip')

        header = urwid.AttrMap(self._title, 'header')
        footer = urwid.AttrMap(self._status, 'footer')

        # Set body to None here, populate in update_widgets
        self._frame = urwid.Frame(None, header, footer)
        self.update_widgets([])

    @staticmethod
    def _palette_entry(attr, fg, bg, mono=''):
        """
        Creates an urwid palette entry with the specified attributes.

        :type  attr: :class:`str`
        :param attr: Attribute name
        :type  fg: :class:`tuple` of (:class:`str`, :class:`str`)
        :param fg: Foreground color: tuple of (standard, high-color) values
        :type  bg: :class:`tuple` of (:class:`str`, :class:`str`)
        :param bg: Background color: tuple of (standard, high-color) values
        :type  mono: :class:`str` or ``None``
        :param mono: Monochrome terminal settings
        :rtype:  :class:`tuple` of (:class:`str`, :class:`str`, :class:`str`, :class:`str`, :class:`str`, :class:`str`)
        :return: urwid palette entry
        """
        if mono:
            return (attr, fg[0] + ',' + mono, bg[0],
                    mono, fg[1] + ',' + mono, bg[1])
        else:
            return (attr, fg[0], bg[0],
                    mono, fg[1], bg[1])

    @staticmethod
    def _format_title(cmd_path, cmd_name):
        """
        Formats the UI title bar based on the provided command path and name.

        :type  cmd_path: :class:`list` of :class:`str`
        :param cmd_path: List of command namespaces
        :type  cmd_name: :class:`str` or ``None``
        :param cmd_name: Command name, or None for a namespace page
        """
        ns = ' '.join(cmd_path)
        if cmd_name:
            return 'vAPI: %s %s' % (ns, cmd_name)
        elif cmd_path:
            return 'vAPI: %s' % ns
        else:
            return 'vAPI'

    @staticmethod
    def _format_output(output):
        """
        Formats the output of a method.

        :type  output: :class:`vmware.vapi.data.value.DataValue`
        :param output: Method output
        :rtype:  :class:`str`
        :return: Formatted output text
        """
        fp = StringIO.StringIO()
        # XXX Add support for other formatters here
        TableVisitor(fp).Format(output)
        return fp.getvalue()

    @staticmethod
    def _format_error(error):
        """
        Formats an error returned by a method.

        :type  error: :class:`vmware.vapi.data.value.ErrorValue`
        :param error: Method error
        :rtype:  :class:`str`
        :return: Formatted error text
        """
        output = ['Command failed with error %s\n' % error.name]
        msg_list = error.get_field('messages')
        if msg_list:
            output += ['Error stack:']
            output += [msg.get_field('default_message').value for msg in msg_list]
        return '\n'.join(output)

    @staticmethod
    def _format_command_line(cmd_path, cmd_name, param_list):
        """
        Formats the command-line equivalent of the specified command invocation.

        :type  cmd_path: :class:`list` of :class:`str`
        :param cmd_path: List of command namespaces
        :type  cmd_name: :class:`str`
        :param cmd_name: Command name
        :type  param_list: :class:`list` of :class:`tuple` of
            (:class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`, :class:`str`)
        :param param_list: List of command (parameter, value) pairs
        :rtype:  :class:`str`
        :return: Command line equivalent of the specified command invocation
        """
        argv = list(cmd_path)
        argv.append(cmd_name)
        if param_list is not None:
            argv += ['--%s %s' % (p.name, quote(v)) for (p, v) in param_list]
        return ' '.join(argv)

    def _get_current_ns(self):
        """
        Returns the CLI NamespaceIdentity for the currently active namespace.

        :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceIdentity`
        :return: Namespace identity for the current namespace
        """
        name = self._cmd_path[-1] if self._cmd_path else ''
        parent = '.'.join(self._cmd_path[:-1])
        return Namespace.Identity(path=parent, name=name)

    def _get_current_ns_path(self):
        """
        Returns the dot-separated namespace path for the current page.

        :rtype:  :class:`str`
        :return: Namespace path
        """
        return '.'.join(self._cmd_path)

    def _get_ns_info(self, ns_id):
        """
        Returns the CLI NamespaceInfo for the specified namespace.  Returns
        None if the namespace is not found, which can happen if the registered
        CLI metadata changes between calls to the server.

        :type  ns_id: :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceIdentity`
        :param ns_id: Namespace identity
        :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo` or ``None``
        :return: Namespace info, or None if the namespace is not found
        """
        try:
            return self._namespace.get(identity=ns_id)
        except NotFound:
            logger.warning('Lookup failed for namespace %s.%s', ns_id.path, ns_id.name)
            return None

    def _get_ns_widget(self, ns_info):
        """
        Creates a widget for selecting the specified namespace.

        :type  ns_info: :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
        :param ns_info: Namespace info
        :rtype:  :class:`urwid.Columns`
        :return: Namespace selection widget
        """
        def on_select_ns_func(button):
            """
             Fires callback when a namespace is selected

            :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Command.CommandIdentity`
            :return: Command identity for the current command
            """
            self.on_select_ns(button.get_label().strip())
        return urwid.Columns([
            ('fixed', 20,
             urwid.Padding(urwid.Button('  ' + ns_info.info.name,
                                        on_select_ns_func),
                           width=len(ns_info.info.name) + 6)),
            ('weight', 1, urwid.Text(ns_info.description))
        ], 0, min_width=8)

    def _get_current_cmd(self):
        """
        Returns the CLI CommandIdentity for the currently active command.

        :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Command.CommandIdentity`
        :return: Command identity for the current command
        """
        parent = self._get_current_ns_path()
        name = self._cmd_name
        return Command.Identity(path=parent, name=name)

    def _get_cmd_info(self, cmd_id):
        """
        Returns the CLI CommandInfo for the specified command.  Returns None
        if the command is not found, which can happen if the registered
        CLI metadata changes between calls to the server.

        :type  ns_id: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandIdentity`
        :param ns_id: Command identity
        :rtype:  :class:`com.vmware.vapi.metadata.cli_client.Commnad.CommandInfo` or ``None``
        :return: Command info, or None if the command is not found
        """
        try:
            return self._command.get(identity=cmd_id)
        except NotFound:
            logger.warning('Lookup failed for command %s.%s', cmd_id.path, cmd_id.name)
            return None

    def _get_cmd_list(self, cmd_path):
        """
        Returns the commands that are available in the specified namespace.
        List will be empty if no commands are registered or if the namespace
        does not exist.

        :type  cmd_path: :class:`str`
        :param cmd_path: Dot-separated namespace path
        :rtype:  :class:`list` of :class:`com.vmware.vapi.metadata.cli_client.Commnad.CommandIdentity`
        :return: List of commands available in the namespace
        """
        try:
            return self._command.list(path=cmd_path)
        except NotFound:
            logger.warning('Command lookup failed for path %s', cmd_path)
            return []

    def _get_cmd_widget(self, cmd_info):
        """
        Defines on select cmd behaviour.

        :type  ns_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
        :param ns_info: Command info
        :rtype:  :class:`urwid.Columns`
        :return: Command selection widget
        """
        def on_select_cmd_func(button):
            """
            Fires callback when a command is selected on a namespace page.

            :type  child: :class:`str`
            :param child: Selected command name
            """
            self.on_select_cmd(button.get_label().strip())
        return urwid.Columns([
            ('fixed', 20,
             urwid.Padding(urwid.Button('  ' + cmd_info.info.name,
                                        on_select_cmd_func),
                           width=len(cmd_info.info.name) + 6)),
            ('weight', 1, urwid.Text(cmd_info.description)),
        ], 0, min_width=8)

    def _get_operation_info(self, cmd_info):
        """
        Returns the API operation info for the specified command.  Returns None
        if the operation is not found, which can happen if the API specified
        in the CLI metadata is not registered on the server.

        :type  cmd_info:  :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
        :param cmd_info: Command info
        :rtype: :class:`com.vmware.vapi.std.introspection_client.Operation.Info` or ``None``
        :return: API operation info, or None if the operation is not found
        """
        try:
            return self._operation.get(cmd_info.service,
                                       cmd_info.operation)
        except NotFound:
            logger.warning('Lookup failed for operation %s.%s', cmd_info.service, cmd_info.operation)
            return None

    @classmethod
    def _get_param_defn(cls, defn, param):
        """
        Returns the DataDefinition for the specified parameter of the
        specified operation.

        :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
        :param defn: Input definition of the operation
        :type  param: :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
        :param param: CLI parameter
        :rtype  :class:`vmware.vapi.data.definition.DataDefinition`
        :return Data definition for the specified parameter
        """
        for field in param.vapi_name.split('.'):
            defn = defn.get_field(field)
        return defn

    def update_widgets(self, widgets):
        """
        Renders the provided list of widgets in the body of the page.

        :type  widget: :class:`list` of :class:`urwid.Widget`
        :param widget: List of widgets to be displayed
        """
        content = urwid.SimpleListWalker(widgets)
        lb_widget = urwid.ListBox(content)
        lb_widget = urwid.Padding(lb_widget, ('fixed left', 2), ('fixed right', 2))
        lb_widget = urwid.Filler(lb_widget, ('fixed top', 1), ('fixed bottom', 1))
        lb_widget = urwid.AttrMap(lb_widget, 'listbox')
        self._frame.set_body(lb_widget)

    def draw_menu(self):
        """
        Renders a namespace menu page.
        """
        self.draw_title()

        ns_id = self._get_current_ns()
        ns_info = self._get_ns_info(ns_id)
        if not ns_info:
            self.draw_status('Namespace not found')
            return

        ns_widgets = []
        ns_id_list = ns_info.children
        if ns_id_list:
            subtitle = urwid.Text('Namespaces')
            subtitle = urwid.AttrMap(subtitle, 'subtitle')
            ns_id_list.sort(key=lambda x: x.name)
            ns_info_list = [self._get_ns_info(ns_id) for ns_id in ns_id_list]
            ns_widgets = [subtitle] + [self._get_ns_widget(ns_info)
                                       for ns_info in ns_info_list
                                       if ns_info is not None]

        cmd_widgets = []
        cmd_path = self._get_current_ns_path()
        cmd_list = self._get_cmd_list(cmd_path)
        if cmd_list:
            subtitle = urwid.Text('Commands')
            subtitle = urwid.AttrMap(subtitle, 'subtitle')
            cmd_list.sort(key=lambda x: x.name)
            cmd_info_list = [self._get_cmd_info(cmd_id) for cmd_id in cmd_list]
            cmd_widgets = [subtitle] + [self._get_cmd_widget(cmd_info)
                                        for cmd_info in cmd_info_list
                                        if cmd_info is not None]

        if ns_widgets and cmd_widgets:
            divider = urwid.Divider()
            widgets = ns_widgets + [divider] + cmd_widgets
            help_text = 'Select a namespace or command'
        elif ns_widgets:
            widgets = ns_widgets
            help_text = 'Select a namespace'
        elif cmd_widgets:
            widgets = cmd_widgets
            help_text = 'Select a command'
        else:
            widgets = []
            help_text = 'No namespaces or commands found'

        widgets = [urwid.AttrMap(w, 'deselect', 'select') for w in widgets]
        self.update_widgets(widgets)
        self.draw_status(help_text)

    def draw_cmd_form(self):
        """
        Renders a command input form.
        """
        self.draw_title()

        cmd_id = self._get_current_cmd()
        cmd_info = self._get_cmd_info(cmd_id)
        if not cmd_info:
            self.draw_status('Command not found')
            return
        op_info = self._get_operation_info(cmd_info)
        if not op_info:
            self.draw_status('Command not found')
            return

        input_defn = convert_data_value_to_data_def(
            op_info.input_definition.get_struct_value())

        # Parameter widgets
        widgets = []
        for param in cmd_info.input:
            defn = self._get_param_defn(input_defn, param)
            if isinstance(defn, StructDefinition):
                # XXX Quick-and-dirty support for pre-R19 metadata
                # that contains structure parameters; flattens all
                # structure parameters, and only goes one level deep.
                # Would be nice to represent structure visually, perhaps
                # by adding a label and indenting structure fields.
                for field_name in defn.get_field_names():
                    widgets += [ParamEdit(defn, param, field_name)]
            else:
                widgets += [ParamEdit(defn, param)]

        self._edit_list = widgets
        widgets = [urwid.AttrWrap(w, 'deselect', 'select') for w in widgets]

        # Submit widget
        widgets.append(urwid.Divider(' '))

        def on_submit_func():
            """
            Fires callback when a command input is submitted.
            """
            self.on_submit()

        submit_widget = urwid.Padding(urwid.Button('[ Submit ]', on_submit_func),
                                      align='center', width=14)
        submit_widget = urwid.AttrMap(submit_widget, 'deselect', 'select')
        widgets.append(submit_widget)

        self.update_widgets(widgets)
        help_text = 'Enter command options and submit request'
        self.draw_status(help_text)

    def draw_cmd_output(self, output):
        """
        Renders a command output page.

        :type  output: :class:`str`
        :param output: Command output text
        """
        self.draw_title()
        widgets = [urwid.Padding(urwid.Text(output),
                                 ('fixed left', 2),
                                 ('fixed right', 2), 20)]
        self.update_widgets(widgets)

    def draw_title(self):
        """
        Renders the title text of the page.
        """
        title = self._format_title(self._cmd_path, self._cmd_name)
        self._title.set_text(title)

    def draw_status(self, status_text):
        """
        Renders the status text of the page.
        """
        self._status.set_text('  ' + status_text)

    def on_select_ns(self, child):
        """
        Callback that fires when a namespace is selected on a namespace page.

        :type  child: :class:`str`
        :param child: Selected namespace name
        """
        self._cmd_path.append(child)
        self.draw_menu()

    def on_select_cmd(self, child):
        """
        Callback that fires when a command is selected on a namespace page.

        :type  child: :class:`str`
        :param child: Selected command name
        """
        self._cmd_name = child
        self.draw_cmd_form()

    def on_submit(self):
        """
        Callback that fires when a command input form is submitted.
        """
        self.run_command()

    def on_escape(self):
        """
        Callback that fires when the escape key is pressed.
        """
        if self._cmd_name:
            # On a command form or result page -- go back to command namespace
            self._cmd_name = None
        elif self._cmd_path:
            # On a namespace menu page -- go back to containing namespace
            self._cmd_path = self._cmd_path[:-1]
        else:
            # At the top level -- exit the app
            raise urwid.ExitMainLoop()
        self.draw_menu()

    def on_unhandled_input(self, key):
        """
        Callback that fires when unhandled input is received.

        :type  key: :class:`str`
        :param key: Unhandled input
        """
        if key == 'esc':
            self.on_escape()
        elif key == 'q':
            raise urwid.ExitMainLoop()

    def run_command(self):
        """
        Runs the command specified by the input form.
        """
        cmd_id = self._get_current_cmd()
        cmd_info = self._get_cmd_info(cmd_id)
        if not cmd_info:
            self.draw_status('Command not found')
            return
        op_info = self._get_operation_info(cmd_info)
        if not op_info:
            self.draw_status('Command not found')
            return
        input_defn = convert_data_value_to_data_def(
            op_info.input_definition.get_struct_value())
        input_val = input_defn.new_value()

        # Get parameter values from the edit boxes
        edit_list = [e for e in self._edit_list if e.get_value() is not None]
        for e in edit_list:
            param = e.get_param()
            field = e.get_field()
            value = e.get_value()
            if field is not None:
                # Pre-R19 structure field: convert to a parameter path
                param_path = '%s.%s' % (param.vapi_name, field)
            else:
                param_path = param.vapi_name

            param_path = param_path.split('.')
            param_name = param_path.pop()
            (val, defn) = (input_val, input_defn)
            # Recursively descend to the structure containing the primitive
            # field, instantiating structure values as needed as we go
            for field in param_path:
                defn = defn.get_field(field)
                if not val.has_field(field):
                    val.set_field(field, defn.new_value())
                val = val.get_field(field)
            # Assign the primitive value to the field
            defn = defn.get_field(param_name)
            param_val = string_value_to_data_value(defn, value)
            val.set_field(param_name, param_val)

        try:
            ctx = self._connector.new_context()
            result = self._api_provider.invoke(cmd_info.service,
                                               cmd_info.operation,
                                               input_val,
                                               ctx)
            success = result.success()
            if success:
                output = self._format_output(result.output)
            else:
                output = self._format_error(result.error)
        except Exception as exc:
            output = str(exc)
            success = False
        self.draw_cmd_output(output)
        self.draw_status('Command %s' % ('succeeded' if success else 'failed'))

    def run(self, cmd_path):
        """
        Launches the Curses UI, starting at the provided namespace path.

        :type  cmd_path: :class:`list` of :class:`str`
        :param cmd_path: Namespace path
        """
        self._cmd_path = cmd_path
        self.draw_menu()
        on_unhandled_input_func = self.on_unhandled_input

        # Create a black border around the main frame
        main_widget = urwid.Padding(self._frame, ('fixed left', 2), ('fixed right', 2))
        main_widget = urwid.Filler(main_widget, ('fixed top', 1), ('fixed bottom', 1))

        loop = urwid.MainLoop(main_widget,
                              self._palette,
                              unhandled_input=on_unhandled_input_func)
        loop.screen.set_terminal_properties(colors=256)
        try:
            loop.run()
        except KeyboardInterrupt:
            pass


def main():
    """
    Main entry point.  Processes command-line arguments and
    launches the Curses UI.
    """
    usage = 'usage: %prog [options] [namespace or command path]'
    parser = OptionParser(usage=usage)
    parser.add_option('--endpoint', dest='endpoint',
                      help='vAPI endpoint [default: %default]',
                      default='http://localhost/vapi')
    parser.add_option('--protocol', dest='protocol',
                      help='vAPI connection protocol [default: %default]',
                      default='json')
    (options, args) = parser.parse_args(sys.argv[1:])

    # Extract the scheme from the endpoint URL
    scheme = options.endpoint.split(':')[0]

    connector = get_connector(scheme,
                              options.protocol,
                              url=options.endpoint)
    curses_ui = CursesUI(connector)
    curses_ui.run(args)

if __name__ == "__main__":
    main()
