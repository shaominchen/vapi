#!/usr/bin/env python

"""
Module for providing a JSON-RPC presentation layer on top of the API.
"""

from __future__ import absolute_import

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015-2016 VMware, Inc.  All rights reserved.'

import os
import sys
try:
    import simplejson as json
except ImportError:
    import json

from vmware.vapi.lib.connect import get_connector
from vmware.vapi.data.serializers.python import build_py_value, build_data_value
from vmware.vapi.data.serializers.introspection import convert_data_value_to_data_def
from vmware.vapi.data.definition import OptionalDefinition
from vmware.vapi.stdlib.client.factories import StubConfigurationFactory

from com.vmware.vapi.std.introspection_client import Operation
from com.vmware.vapi.std.errors_client import NotFound


class JSONRPCException(Exception):
    """
    Exception class that encapsulates a JSON-RPC error.

    Differences in error objects across the versions:

    -- The 1.0 spec is silent on the error format, to the point of
       not even including an example of an error response.

    -- The 1.1 working draft states that the error should be an object
       with the following fields (all but error are required):
          * name: A String value that MUST read "JSONRPCError".
          * code: A Number value that indicates the actual error that
                  occurred. This MUST be an integer between 100 and 999.
          * message: A String value that provides a short description of the
                     error. The message SHOULD be limited to a single sentence.
          * error: A JSON Null, Number, String or Object value that carries
                   custom and application-specific error information.
                   Error objects MAY be nested using this property.
       The working draft includes a table of errors, but no error code values.

    -- The 2.0 spec states that the error should be an object
       with the following fields (all but data are required):
          * code: A Number that indicates the error type that occurred.
                  This MUST be an integer.
          * message: A String providing a short description of the error.
                     The message SHOULD be limited to a concise single sentence.
          * data: A Primitive or Structured value that contains additional
                  information about the error.  The value of this member is
                  defined by the Server (e.g. detailed error information,
                  nested errors etc.).
       The spec reserves code range [-32768, -32000] for pre-defined errors,
       some of which are enumerated in the spec

    Dealing with these differences:

    -- Since 1.1 appears to have been abandoned before being finalized
       and doesn't contain a list of error codes, for simplicity we're
       going to punt and use the 2.0 error codes for 1.1 errors.
    -- Since 1.0 doesn't define an error format, we'll re-use the 1.1
       error format.
    """

    # Error codes defined by the specification
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603

    # Implementation-defined server errors
    SERVER_ERROR = -32000

    # Application error codes
    APPLICATION_ERROR = -1

    _messages = {
        PARSE_ERROR: 'Parse error',
        INVALID_REQUEST: 'Invalid request',
        METHOD_NOT_FOUND: 'Method not found',
        INVALID_PARAMS: 'Invalid params',
        INTERNAL_ERROR: 'Internal error',
        SERVER_ERROR: 'Server error',
        APPLICATION_ERROR: 'Application error',
    }

    def __init__(self, version, code, message=None, data=None):
        """
        Creates a new JSONRPCException instance.

        :type  version: :class:`str`
        :param version: JSON-RPC version
        :type  code: :class:`int`
        :param code: JSON-RPC error code (from the JSON-RPC 2.0 draft standard)
        :type  message: :class:`str` or ``None``
        :param message: Error message; if None, an 'Internal error' message will be used
        :type  data: :class:`object` or ``None``
        :param data: Optional JSON-serializable data payload for the error
        """
        if message is None:
            message = self._messages.get(code, 'Internal error')
        Exception.__init__(self, message)

        self._dict = {
            'code': code,
            'message': message,
        }
        if version in ['1.0', '1.1']:
            self._dict['name'] = 'JSONRPCError'

        if data is not None:
            if version in ['1.0', '1.1']:
                self._dict['error'] = data
            else:
                self._dict['data'] = data

    @property
    def error(self):
        """
        Returns the error as a Python dict suitable for JSON serialization
        in the method response.
        """
        return self._dict


class JSONRPCHandler(object):
    """
    Class that handles vAPI JSON-RPC requests.
    """
    def __init__(self, vapi_connector):
        """
        Initializes a JSONRPCHandler backed by a vAPI server.

        :type  connector: :class:`vmware.vapi.protocol.client.connector.Connector`
        :param connector: vAPI connector object
        """
        stub_config = StubConfigurationFactory.new_std_configuration(vapi_connector)
        self._connector = vapi_connector
        self._operation = Operation(stub_config)

    @staticmethod
    def _get_version(request):
        """
        Parses the version number from the JSON-RPC request object.

        :type  request: :class:`dict`
        :param request: Parsed JSON-RPC request object
        :rtype:  :class:`str`
        :return: Request version string
        :raise: :class:`JSONRPCException`: If the request doesn't contain
            a valid version property
        """
        if 'version' in request:
            version = request['version']
            if version != '1.1':
                # Version unsupported but specified using the 1.1 style
                raise JSONRPCException('1.1', JSONRPCException.INVALID_REQUEST)
        elif 'jsonrpc' in request:
            version = request['jsonrpc']
            if version != '2.0':
                raise JSONRPCException('2.0', JSONRPCException.INVALID_REQUEST)
        else:
            version = '1.0'
        return version

    @staticmethod
    def _get_params(version, request):
        """
        Parses the method parameters from the JSON-RPC request object.

        :type  version: :class:`str`
        :param version: JSON-RPC request version
        :type  request: :class:`dict`
        :param request: Parsed JSON-RPC request object
        :rtype:  :class:`dict` or :class:`list`
        :return: Parameter list (from positional parameters) or dict
            (for keyword parameters)
        :raise: :class:`JSONRPCException`: If the request is a JSON-RPC notification,
            the parameters property is missing (JSON-RPC 1.0), or the parameters
            are not of the expected type (list for JSON-RPC 1.0, list or dict
            for later versions)
        """
        if 'id' in request:
            if request['id'] is None and version in ['1.0', '1.1']:
                raise JSONRPCException(version, code=JSONRPCException.SERVER_ERROR,
                                       message='Notifications are not supported')
        elif version == '1.0':
            # JSON-RPC 1.0 spec implies this property is required,
            # but some client libraries don't set it so we'll allow it
            pass
        elif version == '2.0':
            raise JSONRPCException(version, code=JSONRPCException.SERVER_ERROR,
                                   message='Notifications are not supported')

        if 'params' in request:
            params = request['params']
        elif version == '1.0':
            raise JSONRPCException(version, code=JSONRPCException.INVALID_REQUEST,
                                   message='No "params" property in request')
        else:
            params = {}

        if version == '1.0':
            if not isinstance(params, list):
                raise JSONRPCException(version, code=JSONRPCException.INVALID_PARAMS,
                                       message='Parameters must be an array')
        else:
            if not isinstance(params, list) and not isinstance(params, dict):
                raise JSONRPCException(version, code=JSONRPCException.INVALID_PARAMS,
                                       message='Parameters must be an array or object')

        return params

    def _json_rpc_invoke(self, version, request):
        """
        Invokes a JSON-RPC request.

        :type  version: :class:`str`
        :param version: JSON-RPC request version
        :type  request: :class:`dict`
        :param request: Parsed JSON-RPC request object
        :rtype:  :class:`dict`
        :return: JSON-serializable response object
        :raise: :class:`JSONRPCException`: If the request is invalid, the method
            does not exist, the provided parameters don't match the method
            signature, or the vAPI operation reports an error.
        """
        api_provider = self._connector.get_api_provider()

        if 'method' not in request:
            raise JSONRPCException(version, code=JSONRPCException.INVALID_REQUEST,
                                   message='No "method" property in request')
        method = request['method']

        params = JSONRPCHandler._get_params(version, request)

        # Split fully-qualified method name into interface and method names
        if '.' not in method:
            raise JSONRPCException(version, code=JSONRPCException.METHOD_NOT_FOUND)
        (iface_name, method_name) = method.rsplit('.', 1)

        # Retrieve method metadata from the Introspection service
        try:
            op_info = self._operation.get(service_id=iface_name,
                                          operation_id=method_name)
        except NotFound:
            raise JSONRPCException(version, code=JSONRPCException.METHOD_NOT_FOUND)
        input_def = convert_data_value_to_data_def(
            op_info.input_definition.get_struct_value())
        input_fields = input_def.get_field_names()

        # Convert positional parameters into keyword parameters
        if isinstance(params, list):
            if len(input_fields) == len(params):
                params = dict(zip(input_fields, params))
            else:
                msg = 'Expected %u parameters, got %u' % (len(input_fields), len(params))
                raise JSONRPCException(version, code=JSONRPCException.INVALID_PARAMS,
                                       message=msg)
        elif isinstance(params, dict):
            invalid_params = [p for p in list(params.keys()) if p not in input_fields]
            if invalid_params:
                msg = 'Unexpected parameter(s): "%s"' % ','.join(invalid_params)
                raise JSONRPCException(version, code=JSONRPCException.INVALID_PARAMS,
                                       message=msg)
            missing_params = [p for p in input_fields
                              if p not in list(params.keys())
                              and not isinstance(input_def.get_field(p), OptionalDefinition)]
            if missing_params:
                msg = 'Missing parameter(s): "%s"' % ','.join(missing_params)
                raise JSONRPCException(version, code=JSONRPCException.INVALID_PARAMS,
                                       message=msg)

        # Create method input structure
        input_value = build_data_value(params, input_def)

        # Invoke the method and return the result
        ctx = self._connector.new_context()
        method_result = api_provider.invoke(iface_name,
                                            method_name,
                                            input_value,
                                            ctx)
        error_defs = {}
        for error_info in op_info.error_definitions:
            error_defs[error_info.name] = convert_data_value_to_data_def(
                error_info.get_struct_value())

        if not method_result.success():
            # XXX Map vAPI error IDs to JSON-RPC error code values?
            # XXX Put English version of topmost error into message field?
            error_name = method_result.error.name
            error_def = error_defs[error_name]
            data = build_py_value(method_result.error, error_def)
            raise JSONRPCException(version,
                                   code=JSONRPCException.APPLICATION_ERROR,
                                   message='Operation failed',
                                   data=data)
        else:
            output_def = convert_data_value_to_data_def(
                op_info.output_definition.get_struct_value())
            return build_py_value(method_result.output, output_def)

    def _handle_json_rpc_internal(self, request):
        """
        Invokes a JSON-RPC request.

        :type  request: :class:`dict`
        :param request: Parsed JSON-RPC request object
        :rtype:  :class:`dict`
        :return: JSON-serializable response object containing either
            a result or an error
        """
        # Initialize result object from request object
        props = ['id', 'version', 'jsonrpc']
        result = dict([(p, request[p]) for p in props if p in request])

        # Parse version number from request object
        try:
            version = JSONRPCHandler._get_version(request)
        except JSONRPCException as e:
            result['error'] = e.error
            return result

        # Initialize error and result fields for version 1.0 requests
        # (fields are both mandatory in 1.0, mutually exclusive in 1.1/2.0)
        if version == '1.0':
            result['error'] = None
            result['result'] = None

        try:
            result['result'] = self._json_rpc_invoke(version, request)
        except JSONRPCException as e:
            result['error'] = e.error
        except Exception as e:
            e = JSONRPCException(version, JSONRPCException.APPLICATION_ERROR,
                                 data=str(e))
            result['error'] = e.error

        return result

    def handle_json_rpc(self, request_string):
        """
        Performs a JSON-RPC request.

        :type  request: :class:`str`
        :param request: JSON-RPC request string
        :rtype:  :class:`str`
        :return: JSON-RPC response string
        """
        try:
            # Parse the JSON request into a Python dict
            request = json.loads(request_string)
        except Exception as e:
            # Parsing failed: generate an error result
            e = JSONRPCException(version='1.0', code=JSONRPCException.PARSE_ERROR)
            result = {'error': e.error}
        else:
            # Parsing succeeded: perform the operation
            result = self._handle_json_rpc_internal(request)

        # Serialize the result to a JSON string
        return json.dumps(result)

    def handle_request(self):
        """
        Performs a JSON-RPC CGI request.
        """
        content_type = os.environ['CONTENT_TYPE']
        content_length = int(os.environ['CONTENT_LENGTH'])
        request_string = sys.stdin.read(content_length) if content_length else ''

        if content_type in ['text/json', 'application/json']:
            result_string = self.handle_json_rpc(request_string)
            status = (200, 'OK')
        else:
            result_string = None
            status = (406, 'Not Acceptable')

        sys.stdout.write('Status: %u %s\r\n' % status)
        sys.stdout.write('Content-Type: %s\r\n' % content_type)
        sys.stdout.write('\r\n')
        if result_string is not None:
            sys.stdout.write(result_string)
            sys.stdout.write('\r\n')


def main():
    """
    Executes a CGI RPC request.
    """
    # Debugging support
    import cgitb
    cgitb.enable()

    # Suppress cgitb deprecation warning
    import warnings
    warnings.filterwarnings('ignore',
                            category=DeprecationWarning,
                            module='cgitb')

    # Configure the vAPI server from the environment
    scheme = os.environ.get('VAPI_SCHEME', 'http')
    protocol = os.environ.get('VAPI_PROTOCOL', 'json')
    kwargs = {}
    if scheme == 'http':
        kwargs['url'] = os.environ.get('VAPI_URL', 'http://localhost:4290/vapi')
    else:
        raise Exception('Unsupported scheme "%s"' % scheme)
    connector = get_connector(scheme, protocol, **kwargs)
    handler = JSONRPCHandler(connector)
    handler.handle_request()

if __name__ == '__main__':
    main()
