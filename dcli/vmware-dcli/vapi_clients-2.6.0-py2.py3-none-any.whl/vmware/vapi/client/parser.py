#!/usr/bin/env python

"""
Module for parsing client input strings and converting them
into vAPI DataValue instances, guided by a DataDefinition.
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015-2016 VMware, Inc.  All rights reserved.'


from vmware.vapi.data.definition import SimpleDefinitionVisitor


class StringParser(SimpleDefinitionVisitor):
    """
    Helper class that uses a DataDefinition to convert
    a string value into a DataValue.

    Types accepted by the visitor:
       integer, double, string, boolean, list, optional
    Visitor will raise ValueError if the provided value cannot be
    interpreted according to the type definition.

    Types not accepted by the visitor:
       void, opaque, blob, struct, error, secret, struct_ref
    Visitor will raise NotIplementedError if the provided
    definition includes one of these types.
    """
    def __init__(self, value):
        SimpleDefinitionVisitor.__init__(self)
        self.string_value = value
        self.data_value = None

    @staticmethod
    def _visit_element(defn, value):
        """
        Helper method that visits an element of a container type
        (list, optional, etc.).

        :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
        :param defn: Data definition of the container type
        :type  value: :class:`str`
        :param value: String value
        """
        visitor = StringParser(value)
        defn.element_type.accept(visitor)
        return visitor.data_value

    def visit_integer(self, defn):
        """
        Visit a IntegerDefinition

        :type  defn: :class:`IntegerDefinition`
        :param defn: Data definition
        """
        self.data_value = defn.new_value(int(self.string_value))

    def visit_double(self, defn):
        """
        Visit a DoubleDefinition

        :type  defn: :class:`DoubleDefinition`
        :param defn: Data definition
        """
        self.data_value = defn.new_value(float(self.string_value))

    def visit_string(self, defn):
        """
        Visit a StringDefinition

        :type  defn: :class:`StringDefinition`
        :param defn: Data definition
        """
        self.data_value = defn.new_value(self.string_value)

    def visit_secret(self, defn):
        """
        Visit a SecretDefinition

        :type  defn: :class:`SecretDefinition`
        :param defn: Data definition
        """
        self.data_value = defn.new_value(self.string_value)

    def visit_boolean(self, defn):
        """
        Visit a BooleanDefinition

        :type  defn: :class:`BooleanDefinition`
        :param defn: Data definition
        """
        is_true = self.string_value.lower() in ['true', 't', 'y', '1']
        is_false = self.string_value.lower() in ['false', 'f', 'n', '0']
        if not is_true and not is_false:
            raise ValueError('Invalid boolean literal "%s"' % self.string_value)
        self.data_value = defn.new_value(is_true)

    def visit_list(self, defn):
        """
        Visit a ListDefinition

        :type  defn: :class:`ListDefinition`
        :param defn: Data definition
        """
        if isinstance(self.string_value, list):
            value = self.string_value
        else:
            value = self.string_value.split(',')
        elt_list = [StringParser._visit_element(defn, elt) for elt in value]
        self.data_value = defn.new_value()
        self.data_value.add_all(elt_list)

    def visit_optional(self, defn):
        """
        Visit a OptionalDefinition

        :type  defn: :class:`OptionalDefinition`
        :param defn: Data definition
        """
        elt_value = StringParser._visit_element(defn, self.string_value)
        self.data_value = defn.new_value(elt_value)


def string_value_to_data_value(defn, value):
    """
    Converts a string value or list of string values into a DataValue
    based on the provided DataDefinition.

    :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
    :param defn: Data definition
    :type  value: :class:`str` or :class:`list` of :class:`str`
    :param defn: String value or list of values
    :rtype: :class:`vmware.vapi.data.value.DataValue`
    :return: Newly created DataValue
    :raise: :class:`NotImplementedError` if the data definition includes
        an unsupported type.
    :raise: :class:`ValueError` if the value cannot be interpreted as
        an instance of the provided data definition.
    """
    visitor = StringParser(value)
    defn.accept(visitor)
    return visitor.data_value
