#!/usr/bin/env python

"""
Module for providing an HTML forms-based UI backed by the API and CLI metadata.
"""

from __future__ import absolute_import

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015-2016 VMware, Inc.  All rights reserved.'

import cgi
import mimeparse
import os
import sys
from pipes import quote
import six

from vmware.vapi.lib.connect import get_connector
from vmware.vapi.data.definition import OptionalDefinition
from vmware.vapi.data.serializers.introspection import convert_data_value_to_data_def
from vmware.vapi.client.parser import string_value_to_data_value
from vmware.vapi.client.lib.formatter import (
    HtmlVisitor, JsonVisitor, SplitCamelCaseName, XmlVisitor,
)
from vmware.vapi.stdlib.client.factories import StubConfigurationFactory

from com.vmware.vapi.std.errors_client import NotFound
from com.vmware.vapi.std.introspection_client import Operation
from com.vmware.vapi.metadata.cli_client import Namespace, Command


_header = '''
<html>
<head>
<script type="text/javascript" src="%(rsrc)s/sorttable.js"></script>
<title>%(title)s</title>
<link rel="stylesheet" type="text/css" href="%(rsrc)s/vapi.css"/>
</head>
<body>
<table class="head"><tr>
<td class="hl">%(title)s</td>
<td class="hr"><a class="nav" href="%(back)s">Back</a></td>
<td class="hr"><a class="nav" href="%(home)s">Home</a></td>
</tr></table>
'''

_footer = '''
</body>
</html>
'''

_form_header = '''
<script language="javascript" type="text/javascript">
function toggle(cbId, textId) {
   document.getElementById(textId).disabled = !document.getElementById(cbId).checked;
}
function submitform() {
   document.getElementById("invoke").submit();
}
</script>
<form id="invoke" action="%(action)s">
'''

_login_form = '''
<form id="login" name="login" action="%s/login" method="post">
<h1>VMware</h1>
<fieldset id="inputs">
<input id="username" type="text" name="user" placeholder="Username" autofocus required/><br/>
<input id="password" type="password" name="password" placeholder="Password" required/><br/>
<label id="invalidlogin">%s</label>
</fieldset>
<fieldset id="actions">
<input id="submit" type="submit" value="Login" />
</fieldset>
</form>
'''

_form_footer = '''
<table><tr class="ft">
<td class="ft" width="99%"></td>
<td class="ft" width="1%"><a href="javascript: submitform()">Invoke Command</a>
</tr></table>
</form>
'''


def _format_param(param, value):
    """
    Formats the specified parameter as a command-line flag.

    :type  param: :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
    :param param: CLI parameter definition
    :type  value: :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or :class:`list` or :class:`str`
    :param value: Parameter value or list of values
    :rtype:  :class:`str`
    :return: Parameter string suitable for CLI use
    """
    if isinstance(value, cgi.FieldStorage) or isinstance(value, cgi.MiniFieldStorage):
        return _format_param(param, value.value)
    elif isinstance(value, list):
        return ' '.join([_format_param(param, elt) for elt in value])
    else:
        return '<nobr>--%s=%s</nobr>' % (param.name, quote(value))


def _format_title(ns_id=None, cmd_id=None, param_list=None, label='vAPI'):
    """
    Formats the title of the form page, consisting of a label and the
    CLI parameters corresponding to the form.

    :type  ns_id: :class:`str` or ``None``
    :param ns_id: Dot-separated namespace path, or None for the top level
    :type  cmd_id: :class:`str` or ``None``
    :param cmd_id: Command name, or None for a namespace page
    :type  param_list: :class:`list` of :class:`tuple` of
        (:class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`,
         :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or :class:`list`)
    :param param_list: Command parameters for an invoke page,
        None for a namespace or command page
    :type  label: :class:`str`
    :param label: Label to be used as a title prefix
    :rtype:  :class:`str`
    :return: Formatted title string
    """
    argv = []
    if ns_id:
        argv += ns_id.split('.')
    if cmd_id:
        argv += [cmd_id]
    if param_list:
        argv += [_format_param(p, v) for (p, v) in param_list]
    if argv:
        return '%s: %s' % (label, ' '.join(argv))
    else:
        return label


def _format_url(base_url, prefix, ns_id=None, child_id=None):
    """
    Formats a URL for the specified namespace or command.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  prefix: :class:`str`
    :param prefix: Prefix to insert before namespace and child IDs
    :type  ns_id: :class:`str` or ``None``
    :param ns_id: Dot-separated namespace path, or None for the top level
    :type  child_id: :class:`str` or ``None``
    :param child_id: Child namespace or command, or None for no child
    :rtype:  :class:`str`
    :return: URL
    """
    path = [base_url, prefix]
    if ns_id:
        path += ns_id.split('.')
    if child_id:
        path += [child_id]
    return '/'.join(path)


def _format_home_url(base_url):
    """
    Formats a URL referring to the top-level table-of-contents page.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :rtype:  :class:`str`
    :return: Top-level table-of-contents URL
    """
    return _format_url(base_url, 'toc')


def _format_back_url(base_url, ns_id=None, cmd_id=None, param_list=None):
    """
    Formats a URL referring to the parent page of the current page.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  ns_id: :class:`str` or ``None``
    :param ns_id: Dot-separated namespace path, or None for the top level
    :type  cmd_id: :class:`str` or ``None``
    :param cmd_id: Command name, or None for a namespace form
    :type  param_list: :class:`list` of :class:`tuple` of
        (:class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`,
         :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or :class:`list`)
    :param param_list: Command parameters for an invoke page,
        None for a namespace or command page
    :rtype:  :class:`str`
    :return: URL
    """
    if param_list is not None:
        return _format_url(base_url, 'form', ns_id, cmd_id)
    elif cmd_id is not None:
        return _format_url(base_url, 'toc', ns_id)
    elif ns_id is not None:
        back_ns_id = '.'.join(ns_id.split('.')[:-1])
        return _format_url(base_url, 'toc', back_ns_id)
    else:
        return _format_home_url(base_url)


def _format_namespace_url(base_url, ns_info):
    """
    Formats a table-of-contents URL for the specified CLI namespace.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  ns_info: :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
    :param ns_info: CLI namespace
    :rtype:  :class:`str`
    :return: URL
    """
    return _format_url(base_url, 'toc', ns_info.info.path, ns_info.info.name)


def _format_command_url(base_url, cmd_info):
    """
    Formats a form URL for the specified CLI command.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_info: CLI command
    :rtype:  :class:`str`
    :return: URL
    """
    return _format_url(base_url, 'form', cmd_info.info.path, cmd_info.info.name)


def _format_invoke_url(base_url, cmd_info):
    """
    Formats an invoke URL for the specified CLI command.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_info: CLI command
    :rtype:  :class:`str`
    :return: URL
    """
    return _format_url(base_url, 'invoke', cmd_info.info.path, cmd_info.info.name)


def _render_html_header(base_url, ns_id=None, cmd_id=None, param_list=None):
    """
    Renders an HTML header for a form on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  ns_id: :class:`str` or ``None``
    :param ns_id: Dot-separated namespace path, or None for the top level
    :type  cmd_id: :class:`str` or ``None``
    :param cmd_id: Command name, or None for a namespace page
    :type  param_list: :class:`list` of :class:`tuple` of
        (:class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`,
         :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or :class:`list`)
    :param param_list: Command parameters for an invoke page,
        None for a namespace or command page
    """
    title = _format_title(ns_id, cmd_id, param_list)
    back_url = _format_back_url(base_url, ns_id, cmd_id, param_list)
    home_url = _format_home_url(base_url)
    print(_header % {'title': title,
                     'rsrc': '%s/..' % base_url,
                     'back': back_url,
                     'home': home_url})


def _render_html_footer():
    """
    Renders an HTML footer for a form on stdout.
    """
    print(_footer)  # pylint: disable=C0325


def _render_html_table(title, rows, attribs, headers=None, force=False):
    """
    Renders an HTML table for a form on stdout.

    :type  title: :class:`str`
    :param title: Table title
    :type  rows: :class:`list` of :class:`list` of :class:`str`
    :param rows: Table content (rows x columns)
    :type  attribs: :class:`list` of :class:`str`
    :param attribs: HTML attributes to be applied to each column of the table
    :type  headers: :class:`list` of :class:`str` or ``None``
    :param headers: Column headers, or None if table does not have a header row
    :type  force: :class:`bool`
    :param force: True if table should always be displayed,
        False if table should be omitted if it has no rows
    """
    if len(rows) == 0 and not force:
        return
    print('<p class="table-title">%s</p>' % title)  # pylint: disable=C0325
    print('<table>')  # pylint: disable=C0325
    if headers is not None:
        print('<tr>%s</tr>' % ''.join(['<th>%s</th>' % h for h in headers]))  # pylint: disable=C0325
    for row in rows:
        cells = []
        row_data = zip(attribs, row)
        for i in six.moves.range(0, len(row_data)):  # pylint: disable=E1101
            (attrib, text) = row_data[i]
            tag = 'th' if i == 0 and headers is None else 'td'
            cells.append('<%s%s>%s</%s>' % (tag, attrib, text, tag))
        print('<tr>%s</tr>' % ''.join(cells))  # pylint: disable=C0325
    print('</table>')  # pylint: disable=C0325


def _render_login_form(base_url, invalid_login_attempt):
    """
    Renders an HTML login form on stdout.

    :type  invalid_login_attempt: :class:`bool`
    :param invalid_login_attempt: True if the previous login attempt failed.
    """
    if invalid_login_attempt:
        print(_login_form % (base_url, 'Invalid credentials'))  # pylint: disable=C0325
    else:
        print(_login_form % (base_url, ''))  # pylint: disable=C0325


def _render_toc_namespaces(base_url, ns_list):
    """
    Renders an HTML table of namespaces on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  ns_list: :class:`list` of
        :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
    :param ns_list: List of namespaces to render
    """
    rows = [('<a href="%s">%s</a>' % (
        _format_namespace_url(base_url, ns_info),
        ns_info.info.name),
             ns_info.description)
            for ns_info in ns_list]
    attribs = [' class="rt"', ' class="rc"']
    _render_html_table('Namespaces', rows, attribs)


def _render_toc_commands(base_url, cmd_list):
    """
    Renders an HTML table of commands on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  cmd_list: :class:`list` of
        :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_list: List of commands to render
    """
    rows = [('<a href="%s">%s</a>' % (_format_command_url(base_url, cmd_info),
                                      cmd_info.info.name),
             cmd_info.description) for cmd_info in cmd_list]
    attribs = [' class="rt"', ' class="rc"']
    _render_html_table('Commands', rows, attribs)


def _format_form_checkbox(param, defn):
    """
    Formats an HTML checkbox for an optional command parameter.

    :type  param: :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
    :param param: CLI parameter definition
    :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
    :param defn: Definition of the parameter
    :rtype:  :class:`str`
    :return: HTML checkbox if parameter is optional, empty string if not
    """
    if isinstance(defn, OptionalDefinition):
        text_name = param.name
        cb_name = '%s-cb' % param.name
        cb_attribs = ['type="checkbox"',
                      'id="%s"' % cb_name,
                      'onchange="toggle(\'%s\', \'%s\')"' % (cb_name, text_name)]
        return '<input %s />' % ' '.join(cb_attribs)
    else:
        return ''


def _format_form_text_box(param, defn):
    """
    Formats an HTML text box for a command parameter.

    :type  param: :class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`
    :param param: CLI parameter definition
    :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
    :param defn: Definition of the parameter
    :rtype:  :class:`str`
    :return: HTML text box
    """
    text_name = param.name
    text_attribs = ['type="text"',
                    'id="%s"' % text_name,
                    'name="%s"' % text_name]
    if isinstance(defn, OptionalDefinition):
        text_attribs += ['disabled="disabled"']
    return '<input %s />' % ' '.join(text_attribs)


def _render_form_table(cmd_info, input_def):
    """
    Renders a command form table to stdout.

    :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_info: CLI command
    :type  input_def: :class:`vmware.vapi.data.definition.StructDefinition`
    :param imput_def: Input definition of the vAPI method
        corresponding to the CLI command
    """
    cb = '<input type="checkbox" disabled>'
    headers = ['Parameter', 'Description', 'Type', cb, 'Value']
    attribs = [' class="p1"', ' class="p2"', ' class="p3"', ' class="p4"', ' class="p5"']

    fields = [(param, input_def.get_field(param.vapi_name))
              for param in cmd_info.input]

    rows = [(SplitCamelCaseName(param.name),
             param.description,
             defn.type,
             _format_form_checkbox(param, defn),
             _format_form_text_box(param, defn))
            for (param, defn) in fields]
    _render_html_table('Parameters', rows, attribs, headers)


def render_login(base_url, invalid_login_attempt=False):
    """
    Renders an HTML login page on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  invalid_login_attempt: :class:`bool`
    :param invalid_login_attempt: True if the previous login attempt failed.
    """
    _render_html_header(base_url)
    _render_login_form(base_url, invalid_login_attempt)
    _render_html_footer()


def render_toc(base_url, ns_info, ns_list, cmd_list):
    """
    Renders an HTML namespace table-of-contents page on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  ns_info: :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
    :param ns_info: CLI namespace
    :type  ns_list: :class:`list` of
        :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
    :param ns_list: List of child namespaces in namespace
    :type  cmd_list: :class:`list` of
        :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_list: List of commands in namespace
    """
    if ns_info.info.path:
        ns_path = '%s.%s' % (ns_info.info.path, ns_info.info.name)
    else:
        ns_path = ns_info.info.name
    _render_html_header(base_url, ns_path)
    if ns_list:
        _render_toc_namespaces(base_url, ns_list)
    if cmd_list:
        _render_toc_commands(base_url, cmd_list)
    _render_html_footer()


def render_form(base_url, cmd_info, op_info):
    """
    Renders an HTML command form page on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_info: CLI command
    :type  op_info: :class:`com.vmware.vapi.std.introspection_client.Info`
    :param op_info: Operation Info
    """
    input_definition = convert_data_value_to_data_def(
        op_info.input_definition.get_struct_value())
    _render_html_header(base_url, cmd_info.info.path, cmd_info.info.name)
    print(_form_header % {'action': _format_invoke_url(base_url, cmd_info)})  # pylint: disable=C0325
    _render_form_table(cmd_info, input_definition)
    print(_form_footer)  # pylint: disable=C0325
    _render_html_footer()


def render_invoke(base_url, cmd_info, param_list, result):
    """
    Renders an HTML command result page on stdout.

    :type  base_url: :class:`str`
    :param base_url: Base URL
    :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
    :param cmd_info: CLI command
    :type  param_list: :class:`list` of :class:`tuple` of
        (:class:`com.vmware.vapi.metadata.cli_client.Command.ParameterInfo`,
         :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or :class:`list`)
    :param param_list: Command parameters
    :type  result: :class:`vmware.vapi.core.MethodResult`
    :param result: Command result
    """
    _render_html_header(base_url, cmd_info.info.path, cmd_info.info.name, param_list)
    if result.success():
        print('<p class="table-title">Result</p>')  # pylint: disable=C0325
        formatter = HtmlVisitor()
        formatter.Format(result.output)
    else:
        # XXX Do something better here
        print('<pre>%s</pre>' % str(result.error))  # pylint: disable=C0325
    _render_html_footer()


def _form_value_to_data_value(defn, value):
    """
    Converts a CGI form value into a DataValue based on the
    provided DataDefintion.

    :type  defn: :class:`vmware.vapi.data.definition.DataDefinition`
    :param defn: Data definition
    :type  value: :class:`cgi.FieldStorage` or :class:`cgi.MiniFieldStorage` or
        :class:`list` of :class:`cgi.FieldStorage` or :class:`list` of :class:`cgi.MiniFieldStorage`
    :param value: Form value
    :rtype: :class:`vmware.vapi.data.value.DataValue`
    :return: Newly created DataValue
    :raise: :class:`NotImplementedError` if the data definition includes
        an unsupported type.
    :raise: :class:`ValueError` if the value cannot be interpreted as
        an instance of the provided data definition.
    """
    if isinstance(value, list):
        value = [v.value for v in value]
    else:
        value = value.value
    return string_value_to_data_value(defn, value)


class CgiHandler(object):
    """
    HTTP interface for retrieving dynamic client information;
    supports returning data in XML or JSON format and as an
    HTML form.  The form is currently generated in code, but
    it might be interesting to deliver it as an XSLT template
    that processes the XML representation of the data.
    """
    def __init__(self, vapi_connector):
        """
        Initializes the CGI handler.

        :type  vapi_connector: :class:`vmware.vapi.protocol.client.connector.Connector`
        :param vapi_connector: Connector to the API server
        """
        stub_config = StubConfigurationFactory.new_std_configuration(vapi_connector)
        self._connector = vapi_connector
        self._api_provider = vapi_connector.get_api_provider()
        self._namespace = Namespace(stub_config)
        self._command = Command(stub_config)
        self._operation = Operation(stub_config)

    @staticmethod
    def _print_header(content_type=None, status=None):
        """
        Prints the CGI response header.

        :type  content_type: :class:`str` or ``None``
        :param content_type: Content type; if None, don't write a
            content-type header.
        :type  status: :class:`str` or ``None``
        :param status: Requeset status; if None, don't write a status header.
        """
        if status is not None:
            sys.stdout.write('Status: %s\r\n' % status)
        if content_type is not None:
            sys.stdout.write('Content-Type: %s\r\n' % content_type)
        sys.stdout.write('\r\n')

    @staticmethod
    def _get_output_content_type():
        """
        Returns the content type for the response.

        Does a best match on the Accept header of the request against the
        list of types we support.  If no Accept header is provided, use the
        content type of the request.

        :rtype:  :class:`str` or ``None``
        :return: Content type for the response, or None if there is no
            suitable supported content type.
        """
        # List of supported content types, in increasing order of preference
        type_list = ['text/xml', 'application/xml',
                     'application/json', 'text/json',
                     'text/plain', 'text/html']
        accept = os.environ['HTTP_ACCEPT'].strip()
        if accept:
            return mimeparse.best_match(type_list, accept)
        else:
            return os.environ['CONTENT_TYPE']

    def handle_toc(self, ns_info, content_type):
        """
        Handles a CGI toc request; writes the HTTP response and namespace
        table-of-contents form to stdout.

        :type  ns_info: :class:`com.vmware.vapi.metadata.cli_client.Namespace.NamespaceInfo`
        :param ns_info: CLI namespace
        :type  content_type: :class:`str`
        :param content_type: Content type of the response
        """
        base_url = os.environ['SCRIPT_NAME']

        if ns_info.info.path:
            ns_path = '%s.%s' % (ns_info.info.path, ns_info.info.name)
        else:
            ns_path = ns_info.info.name

        try:
            ns_list = [self._namespace.get(identity=child_id)
                       for child_id in ns_info.children]
            cmd_list = [self._command.get(identity=cmd_id)
                        for cmd_id in self._command.list(path=ns_path)]
        except NotFound:
            # This should only happen if the metadata is internally
            # inconsistent or if it changed between calls; raise an
            # exception so we return an internal server error for now.
            raise Exception('Error retrieving command information')

        CgiHandler._print_header(content_type=content_type)
        if content_type == 'text/html':
            render_toc(base_url, ns_info, ns_list, cmd_list)
        else:
            raise Exception('Unsupported content type "%s"' % content_type)

    def handle_form(self, cmd_info, op_info, content_type):  # pylint: disable=R0201
        """
        Handles a CGI form request; writes the HTTP response and command
        invocation form to stdout.

        :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
        :param cmd_info: CLI command
        :type  op_info: :class:`com.vmware.vapi.std.introspection_client.Info`
        :param op_info: Operation Info
        :type  content_type: :class:`str`
        :param content_type: Content type of the response
        """
        base_url = os.environ['SCRIPT_NAME']
        CgiHandler._print_header(content_type=content_type)
        if content_type == 'text/html':
            render_form(base_url, cmd_info, op_info)
        else:
            raise Exception('Unsupported content type "%s"' % content_type)

    def handle_invoke(self, cmd_info, op_info, form, content_type):
        """
        Handles a CGI invoke request; invokes the method using the
        parameters from the form, and writes the HTTP response and
        command invocation results to stdout.

        :type  cmd_info: :class:`com.vmware.vapi.metadata.cli_client.Command.CommandInfo`
        :param cmd_info: CLI command
        :type  op_info: :class:`com.vmware.vapi.std.introspection_client.Info`
        :param op_info: Operation Info
        :type  form: :class:`cgi.FieldStorage`
        :param form: Form data containing command parameters
        :type  content_type: :class:`str`
        :param content_type: Content type of the response
        """
        base_url = os.environ['SCRIPT_NAME']

        param_list = [(p, form[p.name]) for p in cmd_info.input if p.name in form]
        input_defn = convert_data_value_to_data_def(op_info.input_definition)
        input_val = input_defn.new_value()

        for (param, form_value) in param_list:
            field = param.vapi_name
            data_defn = input_defn.get_field(field)
            data_val = _form_value_to_data_value(data_defn, form_value)
            input_val.set_field(field, data_val)

        ctx = self._connector.new_context()
        result = self._api_provider.invoke(cmd_info.service,
                                           cmd_info.operation,
                                           input_val,
                                           ctx)

        CgiHandler._print_header(content_type=content_type)
        if content_type == 'text/html':
            render_invoke(base_url,
                          cmd_info,
                          param_list,
                          result)
        elif content_type in ['application/json', 'text/json']:
            JsonVisitor().Format(result.output if result.success() else result.error)
        elif content_type in ['text/xml', 'application/xml']:
            XmlVisitor().Format(result.output if result.success() else result.error)
        else:
            raise Exception('Unsupported content type "%s"' % content_type)

    def handle_request(self):
        """
        Handles a CGI request; writes the HTTP response and contents to stdout.
        """
        import cgitb
        cgitb.enable()

        cmd = os.environ['PATH_INFO'].strip('/')

        # Default to the top-level table of contents
        if not cmd:
            cmd = 'toc'

        content_type = CgiHandler._get_output_content_type()
        if not content_type:
            CgiHandler._print_header(content_type=None, status='406 Not Acceptable')
            return

        path_list = cmd.split('/')
        op = path_list.pop(0)
        name = path_list[-1] if path_list else ''
        parent_path = '.'.join(path_list[:-1])

        if op in ['toc']:
            ns_id = Namespace.Identity(name=name, path=parent_path)
            try:
                ns_info = self._namespace.get(identity=ns_id)
            except NotFound:
                raise Exception('Namespace "%s" not found in namespace "%s"' %
                                (name, parent_path))
        elif op in ['form', 'invoke']:
            # Get metadata for the CLI operation
            cmd_id = Command.Identity(name=name, path=parent_path)
            try:
                cmd_info = self._command.get(identity=cmd_id)
            except NotFound:
                raise Exception('Command "%s" not found in namespace "%s"' %
                                (name, parent_path))
            # Get method metadata for the corresponding API method
            try:
                op_info = self._operation.get(service_id=cmd_info.service,
                                              operation_id=cmd_info.operation)
            except NotFound:
                raise Exception('Operation "%s.%s" is not available' %
                                (cmd_info.service, cmd_info.operation))

        if op == 'toc':
            self.handle_toc(ns_info, content_type)
        elif op == 'form':
            self.handle_form(cmd_info, op_info, content_type)
        elif op == 'invoke':
            self.handle_invoke(cmd_info, op_info, cgi.FieldStorage(), content_type)
        else:
            raise Exception('Unsupported operation "%s"' % op)


def main():
    """
    When run directly, execute a CGI request
    """
    # Debugging support
    import cgitb
    cgitb.enable()

    # Suppress cgitb deprecation warning
    import warnings
    warnings.filterwarnings('ignore',
                            category=DeprecationWarning,
                            module='cgitb')

    # Configure the vAPI server from the environment
    scheme = os.environ.get('VAPI_SCHEME', 'http')
    protocol = os.environ.get('VAPI_PROTOCOL', 'json')
    kwargs = {}
    if scheme == 'http':
        kwargs['url'] = os.environ.get('VAPI_URL', 'http://localhost:4290/vapi')
    else:
        raise Exception('Unsupported scheme "%s"' % scheme)
    connector = get_connector(scheme, protocol, **kwargs)
    handler = CgiHandler(connector)
    handler.handle_request()

if __name__ == '__main__':
    main()
