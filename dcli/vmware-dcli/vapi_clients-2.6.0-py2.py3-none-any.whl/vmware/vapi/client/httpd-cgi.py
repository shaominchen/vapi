#!/usr/bin/env python

"""
CGI HTTP Server.

This module builds on BaseHTTPServer by implementing the standard GET, POST,
and HEAD requests in a fairly straightforward manner.

Todo:
XXX Factor the CGI server from the CLI application so that the CGI server can
    be combined with other servers.
"""

from __future__ import absolute_import

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright (c) 2015-2016 VMware, Inc.  All rights reserved.'

import sys
import os
import BaseHTTPServer  # pylint: disable=W0611
import SimpleHTTPServer
import CGIHTTPServer
from SocketServer import ThreadingMixIn  # pylint: disable=W0611

import optparse
import re

# Disabling a warning in is_custom_cgi, but only works if it's up here.  Hrmm.
# pylint: disable=W0201


class CustomCGIHTTPRequestHandler(CGIHTTPServer.CGIHTTPRequestHandler):
    """
    CGI Server
    """
    cgi_pattern = None
    favicon = ''.join([
        '\x00\x00\x01\x00\x01\x00\x10\x10\x10\x00\x01\x00\x04\x00\x28\x01',
        '\x00\x00\x16\x00\x00\x00\x28\x00\x00\x00\x10\x00\x00\x00\x20\x00',
        '\x00\x00\x01\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x13\x0b',
        '\x00\x00\x13\x0b\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\xee\xee',
        '\xee\x00\xd6\xd5\xd5\x00\xcc\xca\xca\x00\xaa\xa7\xa7\x00\x68\x63',
        '\x63\x00\x95\x92\x91\x00\x7b\x78\x77\x00\xbb\xb9\xb8\x00\x8e\x8a',
        '\x8a\x00\x70\x6c\x6b\x00\xe5\xe4\xe4\x00\xa1\x9e\x9e\x00\x61\x5d',
        '\x5c\x00\x53\x4e\x4d\x00\x84\x80\x7f\x00\x00\x00\x00\x00\xf6\xdd',
        '\xdd\xdd\xdd\xdd\xdd\x6f\x6d\xdd\xdd\xdd\xdd\xdd\xdd\xd6\xdd\xdd',
        '\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd',
        '\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xcb\x9d\x4b\xcd\xb9\xd8\x8d\xdd\x30',
        '\x2d\x50\x64\x03\xd0\x1d\xd4\xaa\x09\x80\x64\x03\xd0\x1d\xdb\x0e',
        '\xa7\x80\x6c\x0b\xd0\x1d\xda\x2d\x30\x20\x35\x02\xe0\x2d\xda\x9d',
        '\x41\x01\x10\xa2\x0a\x5d\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd',
        '\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\x6d\xdd',
        '\xdd\xdd\xdd\xdd\xdd\xd6\xf6\xdd\xdd\xdd\xdd\xdd\xdd\x6f\x80\x01',
        '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
        '\x00\x00\x00\x00\x00\x6e\x00\x00\x00\x74\x00\x00\x00\x20\x00\x00',
        '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x66\x00\x00',
        '\x00\x53\x00\x00\x00\x76\x00\x00\x00\x6e\x80\x01\x0c\x00',
    ])

    def is_custom_cgi(self):
        """
        Checks whether the requested path should be treated as a CGI script
        according to the provided regex pattern.

        :rtype:  :class:`bool`
        :return: True if the path is a CGI script, False otherwise.
        """
        path = self.path
        if self.cgi_pattern and self.cgi_pattern.match(path):
            self.cgi_info = "", path[1:]
            return True
        return False

    def is_cgi(self):
        """
        Checks whether the requested path should be treated as a CGI script.

        :rtype:  :class:`bool`
        :return: True if the path is a CGI script, False otherwise.
        """
        return self.is_custom_cgi() or CGIHTTPServer.CGIHTTPRequestHandler.is_cgi(self)

    def do_GET(self):
        """
        Serve a GET request.
        """
        if self.path == '/favicon.ico':
            self.wfile.write(self.favicon)
        elif self.is_cgi():
            self.run_cgi()
        else:
            SimpleHTTPServer.SimpleHTTPRequestHandler.do_GET(self)

    def do_PUT(self):
        """
        Serve a PUT request.
        """
        if self.is_cgi():
            self.run_cgi()
        else:
            raise Exception('PUT not supported on non-CGI path "%s"' % self.path)

    def do_DELETE(self):
        """
        Serve a DELETE request.
        """
        if self.is_cgi():
            self.run_cgi()
        else:
            raise Exception('DELETE not supported on non-CGI path "%s"' % self.path)


class ThreadedHTTPServer(ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """
    Handle requests in a separate thread.
    """
    pass


def StartServer(port):
    """
    Start the CGI enabled HTTP server on the specified port.

    :type  port: :class:`int`
    :param port: Port used for accepting CGI requests.
    :rtype  :class:`CGIHTTPServer.CGIHTTPRequestHandler`
    :return CGI request handler
    """
    Handler = CustomCGIHTTPRequestHandler
    Handler.protocol_version = "HTTP/1.0"
    httpd = ThreadedHTTPServer(("", port), Handler)

    return httpd


def RunServer(httpd):
    """
    Run the provided CGI server.

    :type  httpd: :class:`CGIHTTPServer.CGIHTTPRequestHandler`
    :param httpd: CGI request handler
    """
    sa = httpd.socket.getsockname()
    sys.stderr.write("Serving CGI Server on %s port %s...\n" % (sa[0], sa[1]))
    httpd.serve_forever()

if __name__ == '__main__':
    parser = optparse.OptionParser()
    parser.add_option('-p', '--port', dest='port', type='int', default=8016,
                      help='TCP port number on which server should run.')
    parser.add_option('-C', '--cgi-expr', dest='cgiexpr', type='str', default=None,
                      help='Regular expression that tells server what path is backed by a CGI script.')
    parser.add_option('-d', '--directory', dest='directory', type='str', default=None,
                      help='Change working directory to specified directory.')
    (options, args) = parser.parse_args()
    if options.cgiexpr is not None:
        sys.stderr.write("Using regex '%s' to match CGI applications.\n" % options.cgiexpr)
        CustomCGIHTTPRequestHandler.cgi_pattern = re.compile(options.cgiexpr)
    if options.directory is not None:
        sys.stderr.write("Working directory: %s\n" % options.directory)
        os.chdir(options.directory)

    server = StartServer(options.port)
    RunServer(server)
