/* **********************************************************
 * Copyright 2013-2016 VMware, Inc. All rights reserved. -- VMware Confidential
 * *********************************************************/

package com.vmware.vapi.idl.generator.restdoc

import org.apache.commons.lang.StringUtils
import com.vmware.vapi.idl.app.messages.MessageEngine
import com.vmware.vapi.idl.app.messages.MessagePrinter
import com.vmware.vapi.idl.generator.restdoc.FromMetadataDescriptionGenerator
import com.vmware.vapi.idl.generator.restdoc.PostProcessMapping
import com.vmware.vapi.idl.model.AbstractNamedNode
import com.vmware.vapi.idl.model.AbstractNamespacedNode
import com.vmware.vapi.idl.model.IdlAttribute
import com.vmware.vapi.idl.model.IdlDocumentation
import com.vmware.vapi.idl.model.IdlEnumeration
import com.vmware.vapi.idl.model.IdlIdentifier
import com.vmware.vapi.idl.model.IdlNamespace
import com.vmware.vapi.idl.model.IdlOperation
import com.vmware.vapi.idl.model.IdlError
import com.vmware.vapi.idl.model.IdlPackage
import com.vmware.vapi.idl.model.IdlParameter
import com.vmware.vapi.idl.model.IdlProduct
import com.vmware.vapi.idl.model.IdlReferenceType
import com.vmware.vapi.idl.model.IdlResult
import com.vmware.vapi.idl.model.IdlService
import com.vmware.vapi.idl.model.IdlStructure
import com.vmware.vapi.idl.model.IdlType
import com.vmware.vapi.idl.model.doc.AtCode
import com.vmware.vapi.idl.model.doc.AtEnumValues
import com.vmware.vapi.idl.model.doc.AtKeyword
import com.vmware.vapi.idl.model.doc.AtLink
import com.vmware.vapi.idl.model.doc.AtLiteral
import com.vmware.vapi.idl.model.doc.DocModel
import com.vmware.vapi.idl.model.doc.LinkConverter
import com.vmware.vapi.idl.model.doc.NameConverter
import com.vmware.vapi.idl.model.doc.ResolvedLinkToMember
import com.vmware.vapi.idl.model.doc.ResolvedLinkToPackage
import com.vmware.vapi.idl.model.doc.ResolvedLinkToType
import com.vmware.vapi.idl.transformer.CommentWriter
import com.vmware.vapi.idl.transformer.HtmlCommentWriter
import com.vmware.vapi.idl.transformer.LanguageHelper
import com.vmware.vapi.idl.transformer.LanguageProperties
import com.vmware.vapi.idl.transformer.TemplateNamingContext
import com.vmware.vapi.idl.util.IndentWriter


import org.apache.commons.lang.StringEscapeUtils
import org.apache.commons.lang.StringUtils

import java.io.ObjectInputStream.GetField;

import org.apache.commons.lang.StringUtils;

import com.vmware.vapi.idl.model.AbstractNamedNode;
import com.vmware.vapi.rest.Constants;
import com.vmware.vapi.rest.converter.VApiErrorToHttpCodeMap;
import com.vmware.vapi.rest.converter.impl.VApiErrorToHttpCodeMapImpl;

class RestLanguageHelper extends LanguageHelper {

    static final String NAME = "restdoc"

    private PostProcessMapping postProcessMapping;
    private OperationUrlHelper operationHelper
    private OperationLinkGenerator operationLinkGenerator
    private StructLinkGenerator structLinkGenerator
    private TypeLinkGenerator typeLinkGenerator
    private VApiErrorToHttpCodeMap vapiErrorToHttpCodeMapper;
    private NavigationHelper navigationHelper;
    // This supplied info, debug, warn and error methods for logging
    @Delegate
    private final static MessageEngine messaging  = new MessagePrinter()
    // This supplies getName() & getQualifiedName() methods
    @Delegate private NameHelper nameHelper
    private NameHelper canonicalNameHelper = new CanonicalNameHelper()
    private String vapiStandardPackage
    private String prefixToRemove
    private String urlPrefixToAdd

    //fyi: required factory method to construct an instance
    static RestLanguageHelper getInstance(
            LanguageProperties properties, TemplateNamingContext naming) {
        return new RestLanguageHelper(properties, naming)
    }

    public RestLanguageHelper(LanguageProperties properties, TemplateNamingContext naming) {
        super(NAME, properties, naming)

        vapiStandardPackage = getVapiStandardPackage()
        prefixToRemove = getPrefixToRemove()
        urlPrefixToAdd = getUrlPrefix()

        nameHelper = new DisplayNameHelperDecorator(canonicalNameHelper, prefixToRemove)
	navigationHelper = new NavigationHelper(nameHelper)
        // TODO[kiril] consider this choice via param to idl toolkit
        // Switch the operation helper to select one or many mappings in the REST doc
        operationHelper = new SimplifiedOperationUrlHelper(canonicalNameHelper)
        operationHelper.setUrlPrefix(urlPrefixToAdd)
        operationLinkGenerator = new OperationLinkGenerator(nameHelper)
        structLinkGenerator = new StructLinkGenerator(nameHelper)
        vapiErrorToHttpCodeMapper = new VApiErrorToHttpCodeMapImpl()
        postProcessMapping = new PostProcessMapping(properties)
    }

    String getVapiStandardPackage() {
        return properties.getProperty("vapi.standard.package") ? properties.getProperty("vapi.standard.package") : ""
    }

    String getPrefixToRemove() {
        return properties.getProperty("prefix.to.remove") ? properties.getProperty("prefix.to.remove") : ""
    }

    String getUrlPrefix() {
        return properties.getProperty("url.prefix") ? properties.getProperty("url.prefix") : ""
    }

    CommentWriter createCommentWriter(String rootDir) {
        LinkConverter linkConverter = new LinkConverterImpl(nameHelper, structLinkGenerator, operationLinkGenerator, rootDir)
        NameConverter nameConverter = new NameConverterImpl(nameHelper)

        return new DescriptionWriter(linkConverter, nameConverter, nameHelper, postProcessMapping).injectTermMapping(this.termMapping)
    }

    FromMetadataDescriptionGenerator createMetadataDescriptionGenerator(String rootDir) {
        return new FromMetadataDescriptionGenerator(nameHelper, structLinkGenerator, createCommentWriter(rootDir))
    }

    List<IdlOperation> getOperations(IdlProduct product) {
        List<IdlOperation> result = new ArrayList<IdlOperation>();
        product.services.each { s ->
            result.addAll(s.getOperations());
        }

        return result
    }

    String getOperationPackageName(IdlOperation operation) {
        return ((AbstractNamespacedNode)operation.declaringNode).namespace.name;
    }

    String genOperationTitle(IdlOperation operation) {
        return getNiceStringName(nameHelper.getQualifiedName(operation.declaringNode)) + ": " +  getNiceName(operation.name)
    }

    String genStructureTitle(IdlStructure idlStructure) {
        return getNiceStringName(nameHelper.getNamespace(idlStructure)) + ": " +  getNiceName(idlStructure.name)
    }

    int getErrorHttpStatusCode(IdlError error) {
        return vapiErrorToHttpCodeMapper.getMajorCodeFor(error.type.namespace.getQualifiedName()
            + "." + error.type.getAsIdentifier().getAsCanonical());
    }

    List<OperationRestUrlPair> getRestUrl(IdlOperation operation) {
        List<OperationRestUrlPair> result = new ArrayList<OperationRestUrlPair>()
        for (String url : operationHelper.constructOperationUris(operation)) {
            OperationRestUrlPair restOperation = new OperationRestUrlPair(operation, url)
            result.add(restOperation)
        }
        return result
    }

    List<OperationRestUrlPair> genAllRestUrls(List<IdlOperation> operations) {
        List<OperationRestUrlPair> result = new ArrayList<OperationRestUrlPair>()
        for (IdlOperation operation : operations) {
            result.addAll(getRestUrl(operation))
        }
        return result
    }

     OperationRestUrlPair genRestUrl(IdlOperation operation) {
        return getRestUrl(operation).get(0)
    }

    List<IdlStructure> getStructures(IdlProduct product) {
        List<IdlStructure> result = new ArrayList<IdlStructure>()
        result.addAll(product.structures)
        product.getServices().each {service ->
            result.addAll(service.getStructures())
        }
        return result
    }

    String getOperationFilePath(IdlOperation operation) {
        return operationLinkGenerator.getOperationFilePath(operation)
    }

    String genStructUrl(IdlIdentifier structName, String structNamespace, String rootDir) {
        return structLinkGenerator.genStructUrl(structName, structNamespace, rootDir)
    }

    String genStructUrl(IdlStructure struct, String rootDir) {
        return genStructUrl(struct.name, struct.namespace.name, rootDir)
    }

    String getOperationInputType(IdlOperation idlOperation) {
        return idlOperation.name.asCapitalizedWords + Constants.INPUT_SUFFIX
    }

    String getOperationOutputType(IdlOperation idlOperation) {
        return idlOperation.name.asCapitalizedWords + Constants.RESULT_SUFFIX
    }

    List<IdlParameter> retrievePathParameters(IdlOperation operation) {
        List<IdlParameter> parameters = operation.parameters
        List<String> templates = operationHelper.constructOperationUris(operation)
        List<String> pathParams = SerializerHelper.extractPathParams(templates)
        List<IdlParameter> result = parameters.findAll({ pathParams.contains(it.name.asCanonical)})
        return result
    }

    List<IdlParameter> retrieveBodyParameters(IdlOperation operation) {
        List<IdlParameter> parameters = operation.parameters
        List<String> templates = operationHelper.constructOperationUris(operation)
        List<String> pathParams = SerializerHelper.extractPathParams(templates)
        List<IdlParameter> result = parameters.findAll({ !pathParams.contains(it.name.asCanonical)})
        return result
    }

    List<String> genOperationParentsLinks(IdlOperation operation, String rootFolder) {
        return operationLinkGenerator.getOperationParentsLinks(operation, rootFolder)
    }

    String genOperationNameLink(OperationRestUrlPair restUrl, String rootFolder = null) {
        operationLinkGenerator.genOperationNameLink(restUrl, rootFolder)
    }

    String genOperationNameLink(IdlOperation operation, String rootFolder = null) {
        operationLinkGenerator.genNameLink(operation, rootFolder)
    }

    String genTypeLink(IdlType type, String rootDir, AbstractNamespacedNode namespacedNode) {
        if (typeLinkGenerator == null) {
            TypeToStructMapper mapper = getTypeToStructMapper(namespacedNode)
            typeLinkGenerator = new TypeLinkGenerator(mapper, nameHelper)
        }
        return typeLinkGenerator.genTypeLink(type, rootDir)
    }

    List<String> genStructureParentsLinks(IdlStructure struct, String rootFolder) {
        return structLinkGenerator.genStructureParentsLinks(struct, rootFolder)
    }

    String genStructLink(IdlStructure struct, String rootDir) {
        return structLinkGenerator.genStructLink(struct, rootDir)
    }

    String genQualifiedStructLink(IdlStructure struct, String rootDir) {
        return structLinkGenerator.genQualifiedStructLink(struct, rootDir)
    }

    List<FormattedFieldInfo> getExpandedAttributesForOperationInput(IdlOperation operation,
                                                                    List<IdlParameter> elementsToKeep,
                                                                    String rootFolder ) {
        if (elementsToKeep == null) elementsToKeep = new ArrayList<IdlParameter>()
        IdlProduct product = findProduct(operation.declaringNode)
        IdlToFieldsConstructor fieldsConstructor = new IdlToFieldsConstructor(product, nameHelper)
        // -1 indicates unlimited expansion, expandingLimit > 0 indicates a real limit
        int expandingLimit = -1
        List<FormattedFieldInfo> fieldInfos = fieldsConstructor.constructExpandedFieldsFromOperationInput(operation,
                                                                                                          elementsToKeep,
                                                                                                          rootFolder,
                                                                                                          expandingLimit)
        for (FormattedFieldInfo info : fieldInfos) {
           String description = genDescription(info.getIdlAttribute(), rootFolder)
           String presentDescription = info.getFormattedDescription() != "" ? info.getFormattedDescription() : ""
           info.setFormattedDescription(description + presentDescription)
        }
        return fieldInfos
    }

    List<FormattedFieldInfo> getExpandedAttributesForOperationResult(IdlOperation operation,
                                                                    String rootFolder) {
        IdlProduct product = findProduct(operation.declaringNode)
        IdlToFieldsConstructor fieldsConstructor = new IdlToFieldsConstructor(product, nameHelper)
        // -1 indicates unlimited expansion, expandingLimit > 0 indicates a real limit
        int expandingLimit = -1
        List<FormattedFieldInfo> fieldInfos = fieldsConstructor.constructExpandedFieldsFromOperationResult(operation,
                                                                                                           rootFolder,
                                                                                                           expandingLimit)
        for (FormattedFieldInfo info : fieldInfos) {
           String description = genDescription(info.getIdlAttribute(), rootFolder)
           String presentDescription = info.getFormattedDescription() != "" ? info.getFormattedDescription() : ""
           info.setFormattedDescription(description + presentDescription)
        }
        return fieldInfos
    }

    List<FormattedFieldInfo> getAttributesForStructure(IdlStructure struct, String rootFolder) {
        IdlProduct product = findProduct(struct)
        IdlToFieldsConstructor fieldsConstructor = new IdlToFieldsConstructor(product, nameHelper)
        // -1 indicates unlimited expansion, expandingLimit > 0 indicates a real limit
        int expandingLimit = 1
        List<FormattedFieldInfo> fieldInfos = fieldsConstructor.constructFieldsFromStructure(struct,
                                                                                             rootFolder,
                                                                                             expandingLimit)
        for (FormattedFieldInfo info : fieldInfos) {
           String description = genDescription(info.getIdlAttribute(), rootFolder)
           String presentDescription = info.getFormattedDescription() != "" ? info.getFormattedDescription() : ""
           info.setFormattedDescription(description + presentDescription)
        }
        return fieldInfos
    }

    String rootFolder(IdlNamespace namespace) {
        return operationLinkGenerator.rootFolder(namespace)
    }

    String genXmlFromOperationInput(IdlOperation operation) {
        IdlProduct product = findProduct(operation.declaringNode)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeOperationInputToXml(operation)
        return result
    }

    String genJsonFromOperationInput(IdlOperation operation) {
        IdlProduct product = findProduct(operation.declaringNode)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeOperationInputToJson(operation)
        return result
    }

    String genUrlFromOperationInput(IdlOperation operation) {
        IdlProduct product = findProduct(operation.declaringNode)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        helper.setOperationUrlHelper(operationHelper);
        String result = helper.serializeOperationInputToUrl(operation)
        return result
    }

    Boolean hasRequestBody(IdlOperation operation) {
        return this.retrieveBodyParameters(operation)
    }

    String genJsonFromOperationResult(IdlResult operationResult) {
        IdlProduct product = findProduct(operationResult.declaringNode.declaringNode)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeOperationResultToJson(operationResult)
        return result
    }

    String genXmlFromOperationResult(IdlResult operationResult) {
        IdlProduct product = findProduct(operationResult.declaringNode.declaringNode)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeOperationResultToXml(operationResult)
        return result
    }

    IdlProduct findProduct(AbstractNamespacedNode namespacedNode) {
        IdlPackage contPackage = namespacedNode.containingPackage
        IdlProduct product

        if (contPackage != null) {
            product = contPackage.product
        } else {
            product = namespacedNode.declaringNode.containingPackage.product
        }

        return product
    }

    String genStructureDescription(IdlStructure structure, String rootDir) {
        String comment = getComment(structure.doc, rootDir)
        String metadataDescription =
                createMetadataDescriptionGenerator(rootDir).generateStructureMetadataDoc(structure, rootDir)
        return "${comment} ${metadataDescription}"
    }

    String genOperationDescription(IdlOperation operation, String rootDir) {
        return getComment(operation.doc, rootDir)
    }

    String genDescription(IdlParameter parameter, String rootDir) {
        String comment = getComment(parameter.doc, rootDir)
        String metadataDesc = createMetadataDescriptionGenerator(rootDir).generateParameterMetadataDoc(parameter, rootDir)
        return "${comment} ${metadataDesc}"
    }

    String genDescription(IdlAttribute att, String rootDir) {
        String comment = getComment(att.doc, rootDir)
        if (comment != null && !comment.isEmpty()) {
            comment = comment + "<p/>"
        }
        String metadataDesc = createMetadataDescriptionGenerator(rootDir).generateAttributeMetadataDoc(att, rootDir)
        return "${comment} ${metadataDesc}"
    }

    String getRequired(IdlAttribute att, rootDir) {
        return createMetadataDescriptionGenerator(rootDir).getRequired(att);
    }

    String genOperationResultDescription(IdlResult opResult, String rootDir) {
        String comment = getComment(opResult.doc, rootDir)
        String metadataDesc = createMetadataDescriptionGenerator(rootDir).generateOperationResultDoc(opResult, rootDir);
        return "${comment} ${metadataDesc}"
    }

    String genOperationResultRequired(IdlResult opResult, rootDir) {
        return createMetadataDescriptionGenerator(rootDir).getRequired(opResult);
    }

    boolean isEmpty(String str) {
        return StringUtils.isEmpty(str);
    }

    TypeToStructMapper getTypeToStructMapper(AbstractNamespacedNode namespacedNode) {
        IdlProduct product = findProduct(namespacedNode)
        TypeToStructMapper mapper = new TypeToStructMapper(product)
    }

    String genXmlFromIdlStructure(IdlStructure struct) {
        IdlProduct product = findProduct(struct)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeToXml(struct)
        return result
    }

    String genJsonFromIdlStructure(IdlStructure struct) {
        IdlProduct product = findProduct(struct)
        SerializerHelper helper = new SerializerHelper(product, canonicalNameHelper)
        String result = helper.serializeToJson(struct)
        return result
    }

    String getComment(IdlDocumentation doc, String rootDir) {
        StringWriter sw = new StringWriter()
        IndentWriter writer = new IndentWriter(sw)
        CommentWriter commentWriter = createCommentWriter(rootDir)
        commentWriter.makeLines(doc.descriptionModel).each { line ->
            writer.indent().print(line)
        }

        return sw.toString()
    }

    List<IdlPackage> getPackages(IdlProduct product) {
        def result = new ArrayList<IdlPackage>(product.getPackages())
        Collections.sort(result)
        return result
    }

    NavigationTree buildOperationsTree(IdlProduct product, String rootDir) {
       return navigationHelper.buildOperationsTree(product, rootDir)
    }

    NavigationTree buildTypesTree(IdlProduct product, String rootDir) {
       return navigationHelper.buildTypesTree(product, rootDir)
    }

    String getNiceName(IdlIdentifier name) {
        return getNiceStringName(name.asCanonical)
    }

    String getNiceStringName(String name) {
        String canonicalWithoutPrefix = nameHelper.getStringName(name)
        return canonicalWithoutPrefix.replaceAll("[_.]" ," ")
    }
}
